#!/usr/bin/env python3
"""Verify every manifest member and reject unexpected or unsafe archive paths."""
import argparse
import hashlib
import json
from pathlib import PurePosixPath
import tarfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('archive')
a=p.parse_args()
with tarfile.open(a.archive) as tar:
    members=tar.getmembers()
    names=[m.name for m in members]
    assert len(names)==len(set(names)), 'Duplicate archive member'
    for member in members:
        path=PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert path.parts[0]=='femu-atc26'
        lowered = member.name.lower()
        assert not any(token in lowered for token in
                       ('notes.pdf', 'instructor', 'recording-kit', 'checked.md',
                        'qualification/', 'qualification.md')), member.name
        assert path.suffix not in ('.tex', '.sty'), member.name
    manifest=json.load(tar.extractfile('femu-atc26/manifest.json'))
    expected={'femu-atc26/'+name for name in manifest['files']}
    assert set(names)==expected|{'femu-atc26/manifest.json'}, 'Unmanifested member'
    for name,entry in manifest['files'].items():
        data=tar.extractfile('femu-atc26/'+name).read()
        assert len(data)==entry['bytes']
        assert hashlib.sha256(data).hexdigest()==entry['sha256'], name
    print(f"PASS: {len(expected)} hashed files, no unexpected archive members")
