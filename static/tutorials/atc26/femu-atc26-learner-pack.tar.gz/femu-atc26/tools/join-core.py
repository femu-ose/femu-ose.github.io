#!/usr/bin/env python3
"""Join the seven exported session PDFs, preserving the conference order."""
from pathlib import Path
from pypdf import PdfReader, PdfWriter
root = Path(__file__).resolve().parents[1]
core = ['S0-architecture','S1-blackbox','S2-fdp','S3-zns','S4-csd','S5-cxl','S6-extending']
out = root / 'release'
out.mkdir(exist_ok=True)
for suffix, label in [('', 'presentation'), ('-handout', 'handout'), ('-notes', 'notes')]:
    writer = PdfWriter()
    for name in core:
        reader = PdfReader(root / 'beamer' / name / f'main{suffix}.pdf')
        writer.append(reader, outline_item=name)
    writer.add_metadata({'/Title': f'FEMU ATC26 tutorial: {label}',
                         '/Author': 'FEMU Open-Source Ecosystem'})
    path = out / f'femu-atc26-{label}.pdf'
    writer.write(path)
    print(f'{path}: {len(writer.pages)} pages')
