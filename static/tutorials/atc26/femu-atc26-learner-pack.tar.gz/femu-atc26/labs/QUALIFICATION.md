# Tutorial qualification, 2026-10-22

Source: public FEMU `1918eb9795baa4483e7721429db5e58c54305878`.
Host: Linux x86-64, KVM, kernel `6.18.7-76061807-generic`.

| Gate | Status |
| --- | --- |
| Public source and interface audit | Complete at this source pin |
| Guard and counter regression tests | Pass |
| Fresh S0 NoSSD data readback | Pass |
| Fresh S1 BBSSD workload | Pass: 16 verified jobs and 16 GiB of measured writes |
| Fresh S2 paired FDP workload | No-hints arm passed; hinted arm result not retrieved |
| Fresh S3 ZNS lifecycle and readback | Pass |
| Fresh S4 real CSD vector-add | Pass |
| Fresh S5 CXL region and readback | Old image failed; replacement kernel qualification interrupted |
| S6 unmodified command regression | Expected failure: Invalid Opcode 0x4001 |
| S6 patched regression | Qtest build passed; red/green and patched guest results not retrieved |
| Independent learner and full rehearsal | Not performed |
| Concurrent participant capacity | Not measured |

The first S1 attempt verified all jobs but failed the requested-volume assertion:
fio reported 16 GiB of writes rather than the assumed 24 GiB. The corrected
recipe specifies 1 GiB per hot/cold job, 16 jobs, and checks 16 GiB. Preserve
the failed attempt and the fresh rerun independently.

The existing CXL image boots Linux 7.0.0-34-generic and enumerates mem0, but
cannot commit a region because the required guest invalidation-test option
is absent. That attempt is a failed CXL preflight, not a passed memory lab.

The host memlock limit prevented locking the full backend. These runs qualify
correctness and counter behavior, not calibrated latency or physical fidelity.

## Connectivity interruption and recovery

XPS became unreachable before full receipt collection. `ssh xps` times out;
`xpsts` refuses the connection and `xps2` closes through the jump route. The
local observed-results JSON records only output actually returned during this
session. It is not a substitute for the complete raw remote receipts.

The final CSD helper now asserts the observed 0x4002 status explicitly; rerun
that helper before freezing the release. S1/S2 also gained additional FDP
configuration snapshots after the first successful baseline. These changes
must be included in the final matched pair.

Remote working directory: `/home/huaicheng/atc26-20261021`.
Do not delete or restart an unidentified process. On reconnection:

1. Inspect `runs/`, `pgrep -af atc26-20261021`, build logs and available RAM.
2. Run `bash ATC26-Tutorials/tools/collect-lab-receipts.sh` locally.
3. Check `kernel-build-final.log`, `runs/fdp1/`, and `runs/s6/` before rerunning.
4. `FEMU-public` is the clean source worktree. The original `FEMU` checkout
   is the teaching checkout with test/solution patches; its `.public` binary
   copy preserves the unmodified build. Verify hashes before choosing one.
5. Boot the CXL guest with the final v6.12 kernel and the prepared initrd,
   then run the guarded S5 helper. The old guest uses an LVM root, so use its
   actual root mapping, not an assumed `/dev/vda1`.
6. Run the patched S6 guest test and finish the qtest red/green record.
7. Rerun the final CSD helper and matching FDP arms, collect receipts, and
   regenerate the learner pack. Stop only owned VMs through their QMP sockets.

No remote process cleanup could be verified after connectivity was lost.
