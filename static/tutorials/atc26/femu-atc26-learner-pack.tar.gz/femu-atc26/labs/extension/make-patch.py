#!/usr/bin/env python3
"""Produce the S6 teaching patch against the frozen public FEMU source.

Only creates a patch file. Apply it to a separate checkout, never a live VM.
Opcode C2h is unallocated in the pinned admin dispatch and mode handlers.
This teaching opcode is not an upstream reservation.
"""
import argparse
import difflib
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('source', type=Path)
p.add_argument('output', type=Path)
a = p.parse_args()
path = 'hw/femu/nvme-admin.c'
old = (a.source / path).read_text()
anchor = '    case NVME_ADM_CMD_DIRECTIVE_SEND:\n'
assert old.count(anchor) == 1
new = old.replace(anchor, '''    case 0xc2: { /* tutorial: read-only, versioned diagnostic */
        uint32_t reply[4] = {
            cpu_to_le32(0x554d4546), /* bytes "FEMU" */
            cpu_to_le32(1),         /* response ABI version */
            cpu_to_le32(n->femu_mode),
            cpu_to_le32(16),        /* response length in bytes */
        };

        /* CDW10 is the requested byte count, exactly 16 for ABI v1. */
        if (le32_to_cpu(cmd->cdw10) != sizeof(reply) || cmd->nsid ||
            cmd->cdw11 || cmd->cdw12 || cmd->cdw13 || cmd->cdw14 ||
            cmd->cdw15) {
            return NVME_INVALID_FIELD | NVME_DNR;
        }
        return dma_read_prp(n, (uint8_t *)reply, sizeof(reply),
                            le64_to_cpu(cmd->dptr.prp1),
                            le64_to_cpu(cmd->dptr.prp2));
    }
''' + anchor)
a.output.write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                               'a/' + path, 'b/' + path)))
