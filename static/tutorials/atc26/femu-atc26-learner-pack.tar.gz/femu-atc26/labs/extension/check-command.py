#!/usr/bin/env python3
"""S6 Linux guest regression. Run as root against the tutorial controller.

Unmodified public FEMU must fail this test; the teaching patch must pass.
The tool issues only a read-only vendor admin request and invalid variants.
"""
import argparse
import ctypes
import fcntl
import os
import struct


class Command(ctypes.Structure):
    _fields_ = [('opcode', ctypes.c_uint8), ('flags', ctypes.c_uint8),
                ('rsvd1', ctypes.c_uint16), ('nsid', ctypes.c_uint32),
                ('cdw2', ctypes.c_uint32), ('cdw3', ctypes.c_uint32),
                ('metadata', ctypes.c_uint64), ('addr', ctypes.c_uint64),
                ('metadata_len', ctypes.c_uint32), ('data_len', ctypes.c_uint32),
                ('cdw10', ctypes.c_uint32), ('cdw11', ctypes.c_uint32),
                ('cdw12', ctypes.c_uint32), ('cdw13', ctypes.c_uint32),
                ('cdw14', ctypes.c_uint32), ('cdw15', ctypes.c_uint32),
                ('timeout_ms', ctypes.c_uint32), ('result', ctypes.c_uint32)]


p = argparse.ArgumentParser(description=__doc__)
p.add_argument('controller')
p.add_argument('--mode', type=int, default=2)
a = p.parse_args()
assert ctypes.sizeof(Command) == 72
fd = os.open(a.controller, os.O_RDONLY)
try:
    for requested, reserved, expected in ((16, 0, 0), (0, 0, 0x4002),
                                           (32, 0, 0x4002), (16, 1, 0x4002)):
        buf = ctypes.create_string_buffer(16)
        cmd = Command(opcode=0xc2, addr=ctypes.addressof(buf), data_len=16,
                      cdw10=requested, cdw11=reserved, timeout_ms=5000)
        raw = bytearray(bytes(cmd))
        status = fcntl.ioctl(fd, 0xc0484e41, raw, True)
        assert status == expected, f'length={requested}: status {status:#x}, expected {expected:#x}'
        if status == 0:
            assert struct.unpack('<4I', buf.raw) == (0x554d4546, 1, a.mode, 16)
        print(f'length={requested}, reserved={reserved}: status={status:#x} OK')
finally:
    os.close(fd)
