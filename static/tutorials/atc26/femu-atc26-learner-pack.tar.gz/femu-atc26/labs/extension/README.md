# S6: one read-only admin command

Use a separate checkout of public FEMU `1918eb9795ba`. This is a teaching
patch, not an upstream feature or a reserved public opcode. C2h was checked
against the pinned admin and mode dispatchers. Repeat that audit when rebasing.

1. Boot the unmodified NoSSD lab. Copy `check-command.py` into the guest.
2. **Guest:** `sudo python3 check-command.py /dev/nvme0 --mode 2`.
   The positive case must fail with Invalid Opcode. Keep that red receipt.
3. **Host, separate checkout:** `git apply /path/to/solution.patch`.
4. Rebuild `ninja -C build qemu-system-x86_64`, stop only this lab VM, and
   start a fresh overlay with the patched binary.
5. Repeat the guest test. All four cases must pass, including exact invalid
   field statuses. Keep the green receipt and both binary hashes.

The response contains a magic, ABI version, mode, and length, each a
little-endian 32-bit integer. CDW10 requests exactly 16 bytes; other command
words and NSID must be zero. FEMU's existing PRP helper validates the transfer.

## Learner exercise

Before opening the solution, locate `nvme_admin_cmd`, trace one Identify
response to `dma_read_prp`, and write the four-field response. Decide what an
old guest should do when it encounters an unknown ABI version. Do not add a
write operation or a new timing model in this exercise.

The guest regression is the end-to-end acceptance gate. The separate qtest
below checks the controller without a guest image. Invalid-PRP fuzzing is an
advanced extension of these bounded tests.

## Emulator regression (no guest image)

Apply `test.patch` first to the separate teaching checkout. Build
`ninja -C build tests/qtest/qos-test`, then from `build/` run:

```bash
QTEST_QEMU_BINARY=$PWD/qemu-system-x86_64 tests/qtest/qos-test \
  -p /x86_64/pc/i440FX-pcihost/pci-bus-pc/pci-bus/femu/femu-tests/tutorial-diagnostic
```

The first positive request must fail before `solution.patch` is applied.
After applying the solution and rebuilding QEMU, the test verifies all four
response fields, the sentinel immediately after the 16-byte response, and
invalid length/reserved-word rejection. Keep both outputs. The guest regression
then checks the same interface through Linux's ioctl path.
