"""Regression checks for counter overflow and destructive-device refusal."""
import importlib.util
from pathlib import Path
import struct
import os
import subprocess
import tempfile
import unittest


def module(name):
    path = Path(__file__).resolve().parents[1] / 'guest' / (name + '.py')
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


stats = module('decode-stats')
guard = module('guard-device')
cxl = module('check-cxl')


class Contract(unittest.TestCase):
    def test_runner_preserves_failed_guest_status(self):
        with tempfile.TemporaryDirectory() as temporary:
            temp = Path(temporary)
            binary = temp / 'bin'
            binary.mkdir()
            fixture = temp / 'fixture' / 'receipt'
            fixture.mkdir(parents=True)
            (fixture / 'status.json').write_text('{"exit_status":23}')
            (binary / 'sshpass').write_text('#!/bin/bash\nshift\nexec "$@"\n')
            (binary / 'ssh').write_text('''#!/bin/bash
command=${!#}
case "$command" in
  *"timeout --signal"*) echo 'deliberate guest failure'; exit 23;;
  "tar -xf"*) cat >/dev/null;;
  "tar -cf"*) tar -cf - -C "$FIXTURE" receipt;;
  *) exit 0;;
esac
''')
            for child in binary.iterdir():
                child.chmod(0o755)
            labs = Path(__file__).resolve().parents[1]
            result = subprocess.run(['bash', str(labs/'bin/preflight.sh'),
                                     '-o', str(temp/'results'),
                                     str(labs/'guest/lab-s0.sh'), '/dev/nvme0n1'],
                                    env={**os.environ, 'PATH':str(binary)+':'+os.environ['PATH'],
                                         'EXPECTED_SERIAL':'test', 'EXPECTED_BYTES':'4096',
                                         'SSH_KEY':'', 'FIXTURE':str(fixture.parent)},
                                    capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            transport = next((temp/'results').glob('*/transport.json'))
            self.assertIn('"ssh_exit":23', transport.read_text())
            self.assertIn('deliberate guest failure', result.stdout)

    def test_cxl_readback_detects_corruption(self):
        cxl.verify_mapping(bytearray(16384))
        class Corrupt(bytearray):
            def __getitem__(self, key):
                value = super().__getitem__(key)
                if isinstance(key, slice):
                    return bytes(len(value))
                return value
        with self.assertRaises(AssertionError):
            cxl.verify_mapping(Corrupt(16384))

    def test_fdp_preserves_high_64_bits(self):
        value = 2**80 + 17
        data = value.to_bytes(16, 'little') + (value*2).to_bytes(16, 'little') + bytes(32)
        counts = stats.decode(data, 'fdp')
        self.assertEqual(counts['HBMW'], value)
        self.assertEqual(stats.waf(counts), 2)

    def test_metadata_and_padding_in_waf(self):
        data = bytearray(512)
        for offset, value in ((8, 100), (16, 20), (24, 100), (264, 5), (280, 10)):
            struct.pack_into('<Q', data, offset, value)
        self.assertEqual(stats.waf(stats.decode(data, 'c0')), 1.35)

    def test_short_log_and_counter_reset_refused(self):
        with self.assertRaises(ValueError):
            stats.decode(bytes(32), 'c0')
        with self.assertRaises(ValueError):
            stats.interval({'HBMW': 1}, {'HBMW': 2})
        self.assertIsNone(stats.waf({'HBMW': 0, 'MBMW': 0}))

    def test_guard_failures(self):
        identity = {'sn': 'ATC26-LAB', 'mn': 'FEMU BlackBox-SSD'}
        disk = {'path': '/dev/nvme0n1', 'type': 'disk', 'size': 4096,
                'mountpoints': [None]}
        def check(d=disk, i=identity, swaps='', holders=()):
            guard.validate(i, {'blockdevices': [d]}, swaps, 'ATC26-LAB', 4096, holders)
        check()
        for changed in ({'mountpoints': ['/']}, {'children': [{'type': 'part'}]},
                        {'size': 8192}, {'type': 'part'}):
            with self.assertRaises(ValueError):
                check(d={**disk, **changed})
        with self.assertRaises(ValueError):
            check(i={**identity, 'sn': 'real-disk'})
        with self.assertRaises(ValueError):
            check(swaps='/dev/nvme0n1 partition 4096 0 -2')
        with self.assertRaises(ValueError):
            check(holders=['dm-0'])


if __name__ == '__main__':
    unittest.main()
