#!/usr/bin/env python3
"""Verify four pages in the explicitly created tutorial devdax region."""
import json
import mmap
import os
from pathlib import Path
import subprocess
import sys


def verify_mapping(mem):
    for page in range(4):
        offset = page * 4096
        payload = (f'FEMU-CXL-page-{page}:'.encode() * 4)[:64]
        mem[offset:offset+len(payload)] = payload
        assert mem[offset:offset+len(payload)] == payload
    prefix = b'FEMU-CXL-page-'
    for page in range(4):
        assert mem[page*4096:page*4096+len(prefix)] == prefix


def main():
    dev, receipt = sys.argv[1:]
    assert dev == '/dev/dax0.0', 'This single-region recipe accepts only dax0.0'
    raw = subprocess.check_output(['daxctl', 'list', '-D'])
    Path(receipt, 'dax.json').write_bytes(raw)
    entries = json.loads(raw)
    assert len(entries) == 1, 'Expected exactly one isolated DAX device'
    entry = entries[0]
    assert entry['chardev'] == 'dax0.0' and entry['mode'] == 'devdax', entry
    assert entry['size'] == 256 * 1024**2, entry
    fd = os.open(dev, os.O_RDWR)
    try:
        size = int(entry['align'])
        assert 16384 <= size <= entry['size']
        with mmap.mmap(fd, size, flags=mmap.MAP_SHARED,
                       prot=mmap.PROT_READ | mmap.PROT_WRITE) as mem:
            verify_mapping(mem)
        print('PASS: four devdax pages retain their written bytes')
    finally:
        os.close(fd)


if __name__ == '__main__':
    main()
