#!/bin/bash
# Guard before any write, then check zone zero's complete lifecycle.
dev=${1:?Usage: lab-s3-zns.sh /dev/nvmeXnY}
source "$(dirname "$0")/lab-common.sh"
lab_start
[[ $(cat "/sys/class/block/$blk/queue/zoned") == host-managed ]] || {
    echo 'Expected a host-managed zoned namespace' >&2; exit 2;
}
root python3 "$LAB_DIR/check-zns.py" "$dev" "$RECEIPT_DIR"
