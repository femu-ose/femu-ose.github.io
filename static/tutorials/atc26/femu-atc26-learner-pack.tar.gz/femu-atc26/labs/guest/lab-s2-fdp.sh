#!/bin/bash
# Same fixed-order, verified workload as S1, using FDP passthrough.
set -euo pipefail
export FDP_PLACE=${2:?Usage: lab-s2-fdp.sh /dev/nvmeXnY 0|1}
exec bash "$(dirname "$0")/lab-s1-waf.sh" "${1:?Explicit namespace required}"
