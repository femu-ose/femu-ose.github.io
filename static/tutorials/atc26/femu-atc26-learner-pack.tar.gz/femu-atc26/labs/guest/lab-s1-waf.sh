#!/bin/bash
# Controlled placement workload. Default: BBSSD. S2 sets FDP_PLACE=0 or 1.
dev=${1:?Usage: lab-s1-waf.sh /dev/nvmeXnY}
source "$(dirname "$0")/lab-common.sh"
lab_start
[[ $EXPECTED_BYTES == 12884901888 ]] || {
    echo 'The placement recipe requires the 12 GiB namespace / 16 GiB raw configuration' >&2
    exit 2
}
engine=libaio
direct=1
filename=$dev
placement=()
if [[ -n ${FDP_PLACE:-} ]]; then
    [[ $FDP_PLACE == 0 || $FDP_PLACE == 1 ]] || exit 2
    engine=io_uring_cmd
    direct=0 # NVMe passthrough already bypasses the page cache; ng is a char device.
    filename=/dev/ng${dev#/dev/nvme}
    root nvme fdp configs "$ctrl" -e 1 -o json >"$RECEIPT_DIR/fdp-config.json"
    root nvme fdp status "$dev" -o json >"$RECEIPT_DIR/fdp-status-before.json"
    [[ -c $filename ]] || { echo 'NVMe generic device missing' >&2; exit 2; }
fi
snap_all() {
    snapshot "$1"
    if [[ -n ${FDP_PLACE:-} ]]; then
        root nvme get-log "$ctrl" -i 0x22 -l 64 --lsi=1 -b >"$RECEIPT_DIR/$1.fdp"
    fi
}
section 'Precondition: fill the same 12 GiB address space with no placement hints'
extra=()
[[ $engine == io_uring_cmd ]] && extra=(--cmd_type=nvme)
root fio --name=fill --filename="$filename" --ioengine="$engine" "${extra[@]}" \
    --direct="$direct" --rw=write --bs=128k --iodepth=16 --size="$EXPECTED_BYTES" \
    --output-format=json --output="$RECEIPT_DIR/fill.json"
root nvme flush "$dev"
snap_all before
section 'Measured phase: fixed-order hot/cold batches, QD16, seed 42'
# Sequential stonewall jobs make the global order reproducible across runs.
# Hot range 1 GiB, cold range 11 GiB; 8 batches x (1 GiB hot + 1 GiB cold).
# Each job performs fio CRC32C verification before the next job starts.
job="$RECEIPT_DIR/workload.fio"
cat >"$job" <<FIO
[global]
filename=$filename
ioengine=$engine
direct=$direct
bs=4k
iodepth=16
rw=randwrite
randrepeat=1
randseed=42
verify=crc32c
verify_fatal=1
do_verify=1
FIO
[[ $engine == io_uring_cmd ]] && echo 'cmd_type=nvme' >>"$job"
[[ ${FDP_PLACE:-0} == 1 ]] && echo 'fdp=1' >>"$job"
for batch in {1..8}; do
    for stream in hot cold; do
        if [[ $stream == hot ]]; then offset=0; size=1G; volume=1G; pid=0;
        else offset=1G; size=11G; volume=1G; pid=1; fi
        printf '\n[%s-%s]\nstonewall\noffset=%s\nsize=%s\nio_size=%s\n' \
            "$stream" "$batch" "$offset" "$size" "$volume" >>"$job"
        [[ ${FDP_PLACE:-0} == 1 ]] && printf 'fdp_pli=%s\n' "$pid" >>"$job"
    done
done
sha256sum "$job"
root fio "$job" --output-format=json --output="$RECEIPT_DIR/overwrite.json"
root nvme flush "$dev"
snap_all after
python3 "$LAB_DIR/decode-stats.py" "$RECEIPT_DIR/after.c0" \
    --before "$RECEIPT_DIR/before.c0" --require-writes | tee "$RECEIPT_DIR/interval.json"
if [[ -n ${FDP_PLACE:-} ]]; then
    root nvme fdp status "$dev" -o json >"$RECEIPT_DIR/fdp-status-after.json"
    python3 "$LAB_DIR/decode-stats.py" "$RECEIPT_DIR/after.fdp" --kind fdp \
        --before "$RECEIPT_DIR/before.fdp" --require-writes | tee "$RECEIPT_DIR/fdp-interval.json"
fi
python3 - "$RECEIPT_DIR/overwrite.json" <<'PY'
import json, sys
jobs = json.load(open(sys.argv[1]))['jobs']
assert len(jobs) == 16 and all(j['error'] == 0 for j in jobs)
assert sum(j['write']['io_bytes'] for j in jobs) == 16 * 1024**3
assert sum(j['read']['io_bytes'] for j in jobs) > 0
print('PASS: all jobs verified; 16 GiB written in the measured phase')
PY
