#!/usr/bin/env python3
"""Decode FEMU C0h or FDP 22h logs at public revision 1918eb9795ba.

All integers are little endian. FDP counters are 128-bit byte counts.
C0h WAF includes data, GC, translation-page and partial-disturb padding writes.
"""
import argparse
import json
from pathlib import Path
import struct

NAMES = '''host_write_pages gc_write_pages nand_write_pages max_block_reads
read_reclaims retention_refreshes buffer_reads buffer_read_hits buffer_writes
buffer_write_hits hybrid_switch_merges hybrid_full_merges hybrid_merge_erases
overworn_blocks grown_bad_blocks retired_lines wl_relocations wl_pages
partial_page_writes plane_reads plane_programs plane_erases energy_uj
gc_stalled_writes gc_stall_passes buffer_full_destages cq_full_completions
pace_copies pace_lines pace_takeovers gc_copyback_pages pd_open_reclaims
pd_pad_pages pd_pad_closes map_write_pages map_read_pages'''.split()


def decode(data, kind):
    size = 512 if kind == 'c0' else 64
    if len(data) != size:
        raise ValueError(f'expected {size} bytes, received {len(data)}')
    if kind == 'fdp':
        return {name: int.from_bytes(data[i * 16:(i + 1) * 16], 'little')
                for i, name in enumerate(('HBMW', 'MBMW', 'MBE'))}
    return dict(zip(NAMES, struct.unpack_from('<36Q', data, 8)))


def interval(after, before):
    result = {k: v - before[k] for k, v in after.items()
              if k != 'max_block_reads'}
    if any(v < 0 for v in result.values()):
        raise ValueError('counter decreased: reset or mismatched snapshots')
    return result


def waf(counts):
    if 'HBMW' in counts:
        host = counts['HBMW']
        media = counts['MBMW']
    else:
        host = counts['host_write_pages']
        media = sum(counts[k] for k in ('nand_write_pages', 'gc_write_pages',
                                        'map_write_pages', 'pd_pad_pages'))
    return media / host if host else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log', type=Path)
    parser.add_argument('--before', type=Path)
    parser.add_argument('--kind', choices=('c0', 'fdp'), default='c0')
    parser.add_argument('--require-writes', action='store_true')
    args = parser.parse_args()
    try:
        counts = decode(args.log.read_bytes(), args.kind)
        result = {'kind': args.kind, 'unit': 'bytes' if args.kind == 'fdp' else 'pages',
                  'cumulative': counts}
        selected = counts
        if args.before:
            selected = interval(counts, decode(args.before.read_bytes(), args.kind))
            result['interval'] = selected
        result['waf'] = waf(selected)
        if args.require_writes and result['waf'] is None:
            raise ValueError('no host writes in the selected interval')
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
