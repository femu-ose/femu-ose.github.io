#!/usr/bin/env python3
"""Exercise zone zero only, with exact state, readback and error checks."""
import json
from pathlib import Path
import re
import subprocess
import sys

dev, dest = sys.argv[1:]
out = Path(dest)
step = 0


def run(*args, negative=False):
    global step
    step += 1
    result = subprocess.run(args, capture_output=True)
    (out / f'{step:02d}.stdout').write_bytes(result.stdout)
    (out / f'{step:02d}.stderr').write_bytes(result.stderr)
    with (out / 'commands.jsonl').open('a') as f:
        f.write(json.dumps({'argv': args, 'exit': result.returncode}) + '\n')
    if not negative:
        assert result.returncode == 0, (args, result.stderr.decode())
    return result


def state(expected, wp=None):
    result = run('nvme', 'zns', 'report-zones', dev, '-s', '0', '-d', '1', '-o', 'json')
    z = json.loads(result.stdout)['zone_list'][0]
    assert z['slba'] == 0 and z['state'] == expected, z
    if wp is not None:
        assert z['wp'] == wp, z
    print(f"state={z['state']}, wp={z['wp']}, capacity={z['cap']}")


lb = int((Path('/sys/class/block') / Path(dev).name / 'queue/logical_block_size').read_text())
assert 4096 % lb == 0
payload = out / 'input.bin'
payload.write_bytes(bytes(range(256)) * 16)
run('nvme', 'zns', 'reset-zone', dev, '-s', '0')
state('EMPTY', 0)
run('nvme', 'zns', 'zone-append', dev, '-s', '0', '-z', '4096', '-d', str(payload))
state('IMP_OPENED', 4096 // lb)
readback = run('dd', f'if={dev}', 'bs=4096', 'count=1', 'iflag=direct', 'status=none').stdout
(out / 'readback.bin').write_bytes(readback)
assert readback == payload.read_bytes()
# LBA zero is behind the write pointer after the append.
r = run('nvme', 'write', dev, '--start-block=0',
        f'--block-count={4096 // lb - 1}', '--data-size=4096',
        f'--data={payload}', negative=True)
error = r.stderr.decode()
assert r.returncode != 0 and re.search(r'ZONE_INVALID_WRITE|Zone Invalid Write', error, re.I), error
state('IMP_OPENED', 4096 // lb)
run('nvme', 'zns', 'close-zone', dev, '-s', '0'); state('CLOSED', 4096 // lb)
run('nvme', 'zns', 'open-zone', dev, '-s', '0'); state('EXP_OPENED', 4096 // lb)
run('nvme', 'zns', 'finish-zone', dev, '-s', '0'); state('FULL')
run('nvme', 'zns', 'reset-zone', dev, '-s', '0'); state('EMPTY', 0)
print('PASS: append readback, expected invalid-write class, state walk and reset')
