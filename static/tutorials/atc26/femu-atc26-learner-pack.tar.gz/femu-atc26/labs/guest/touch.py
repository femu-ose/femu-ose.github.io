#!/usr/bin/env python3
"""touch.py DEV r|w PAGE... : one 1-byte load or store per 4 KiB device page."""
import mmap, os, sys

dev, op, pages = sys.argv[1], sys.argv[2], [int(p) for p in sys.argv[3:]]
size = (max(pages) // 512 + 1) * (2 << 20)       # whole 2 MiB dax units
fd = os.open(dev, os.O_RDWR)
m = mmap.mmap(fd, size, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE)
for p in pages:
    if op == "w":
        m[p * 4096] = 0x5A
    else:
        m[p * 4096]
m.close()
os.close(fd)
