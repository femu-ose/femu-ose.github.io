#!/usr/bin/env python3
"""Fail closed before destructive lab I/O. No device-name defaults."""
import json
import os
from pathlib import Path
import sys


def validate(identity, inventory, swaps, serial, size, holders):
    if str(identity.get('sn', '')).strip() != serial:
        raise ValueError('serial does not match the explicit expected serial')
    model = str(identity.get('mn', '')).lower()
    if not any(s in model for s in ('femu', 'blackbox-ssd', 'whitebox-ssd',
                                    'computational', 'zms', 'nossd')):
        raise ValueError('controller is not a recognized FEMU model')
    devices = inventory.get('blockdevices', [])
    if len(devices) != 1 or devices[0].get('type') != 'disk':
        raise ValueError('expected one whole namespace')
    disk = devices[0]
    if int(disk['size']) != int(size):
        raise ValueError('namespace size differs from the launch receipt')
    # Partitioned disks are excluded, even when currently unmounted.
    if disk.get('children'):
        raise ValueError('namespace has partitions or dependent devices')
    if any(disk.get('mountpoints') or []):
        raise ValueError('namespace is mounted')
    if disk['path'] in swaps.split() or holders:
        raise ValueError('namespace is swap or has kernel holders')


def main():
    dev, serial, size = sys.argv[1:]
    holders_path = Path('/sys/class/block') / Path(dev).name / 'holders'
    try:
        validate(json.loads(os.environ['LAB_IDENTITY']),
                 json.loads(os.environ['LAB_INVENTORY']),
                 os.environ['LAB_SWAPS'], serial, size,
                 list(holders_path.iterdir()))
    except (ValueError, KeyError, OSError) as error:
        sys.exit(f'REFUSED: {error}')
    print(f'Guard passed: {dev}, serial={serial}, bytes={size}; disposable lab data only')


if __name__ == '__main__':
    main()
