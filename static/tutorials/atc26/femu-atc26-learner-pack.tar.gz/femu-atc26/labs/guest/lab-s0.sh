#!/bin/bash
# First verified I/O. Requires a disposable, unpartitioned FEMU namespace.
dev=${1:?Usage: lab-s0.sh /dev/nvmeXnY}
source "$(dirname "$0")/lab-common.sh"
lab_start
section 'Predict: does a successful write prove the returned bytes are correct?'
snapshot before
python3 - "$RECEIPT_DIR/input.bin" <<'PY'
from pathlib import Path
import sys
Path(sys.argv[1]).write_bytes(bytes(range(256)) * 4096)
PY
root dd if="$RECEIPT_DIR/input.bin" of="$dev" bs=1M count=1 seek=4 oflag=direct status=none
root nvme flush "$dev"
root dd if="$dev" of="$RECEIPT_DIR/readback.bin" bs=1M count=1 skip=4 iflag=direct status=none
cmp "$RECEIPT_DIR/input.bin" "$RECEIPT_DIR/readback.bin"
sha256sum "$RECEIPT_DIR/input.bin" "$RECEIPT_DIR/readback.bin"
snapshot after
python3 "$LAB_DIR/decode-stats.py" "$RECEIPT_DIR/after.c0" \
    --before "$RECEIPT_DIR/before.c0" >"$RECEIPT_DIR/counters.json"
echo 'PASS: 1 MiB readback matches. NoSSD need not increment NAND counters.'
