#!/bin/bash
# Source after setting dev from a REQUIRED positional argument.
set -euo pipefail
LAB_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
root() {
    if [[ $EUID == 0 ]]; then "$@";
    elif sudo -n true 2>/dev/null; then sudo "$@";
    else printf '%s\n' "${GUEST_PASS:-femu}" | sudo -S -p '' "$@"; fi
}
section() { printf '\n### %s\n' "$*"; }
lab_start() {
    : "${dev:?pass the explicit disposable FEMU namespace}"
    : "${EXPECTED_SERIAL:?set EXPECTED_SERIAL from the launch receipt}"
    : "${EXPECTED_BYTES:?set EXPECTED_BYTES from the launch receipt}"
    [[ $dev =~ ^/dev/nvme[0-9]+n[0-9]+$ && -b $dev ]] || {
        echo 'Expected an existing whole NVMe namespace, not a partition' >&2; exit 2;
    }
    ctrl=${dev%n*}
    blk=${dev##*/}
    local identity inventory swaplist
    identity=$(root nvme id-ctrl "$ctrl" -o json)
    inventory=$(lsblk --json --bytes -o NAME,PATH,TYPE,SIZE,MOUNTPOINTS "$dev")
    swaplist=$(cat /proc/swaps)
    LAB_IDENTITY="$identity" LAB_INVENTORY="$inventory" LAB_SWAPS="$swaplist" \
    python3 "$LAB_DIR/guard-device.py" "$dev" "$EXPECTED_SERIAL" "$EXPECTED_BYTES"
    RECEIPT_DIR=${RECEIPT_DIR:-$(mktemp -d /tmp/femu-lab.XXXXXXXX)}
    mkdir -p "$RECEIPT_DIR"
    printf '%s\n' "$identity" >"$RECEIPT_DIR/identity.json"
    printf '%s\n' "$inventory" >"$RECEIPT_DIR/block-devices.json"
    { uname -a; nvme version; fio --version; } >"$RECEIPT_DIR/versions.txt"
    printf 'receipt: %s\n' "$RECEIPT_DIR"
    trap 'lab_finish "$?"' EXIT
}
lab_finish() {
    local status=$1
    printf '{"exit_status":%d}\n' "$status" >"$RECEIPT_DIR/status.json"
    printf 'LAB RESULT: %s\n' "$status"
}
snapshot() {
    root nvme get-log "$ctrl" --log-id=0xc0 --log-len=512 --raw-binary >"$RECEIPT_DIR/$1.c0"
}
