#!/bin/bash
# lab-s4-csd.sh - Lab S4 inside the guest: drive one computational storage
# program through its whole lifecycle and check the data it returns.
#
# Usage: lab-s4-csd.sh [/dev/nvme0n1]
# Needs: ./csd-passthru (static build of hw/femu/tests/csd/csd-passthru.c)
#        in the current directory, and csd-vadd.so in the host's
#        csd_program_dir (femu-lab.sh csd sets it).
# Env:   GUEST_PASS (femu)
set -euo pipefail

dev=${1:?Pass an explicit disposable FEMU namespace}
ctrl=${dev%n[0-9]*}
tool=${2:-/usr/local/bin/csd-passthru}
fail=0

source "$(dirname "$0")/lab-common.sh"
lab_start
sha256sum "$tool" >"$RECEIPT_DIR/tool.sha256"

section() { printf '\n### %s\n' "$*"; }
run() { printf '$ %s\n' "${*#"$tool "}" | sed "s|^|csd-passthru |; s|^csd-passthru nvme|nvme|"; root "$@"; local rc=$?; if ((rc)); then echo "(exit $rc)"; fi; return $rc; }
expect_ok() { run "$@" || fail=1; }

section "1. is it a CSD?"
root nvme list | sed -n '1,3p'
mn=$(root nvme id-ctrl "$ctrl" | awk -F': ' '/^mn /{print $2}')
echo "model: $mn"
[[ $mn == *Computational* ]] || { echo "not the FEMU CSD controller"; echo "LAB-S4 FAIL"; exit 1; }

section "2. whole lifecycle with a phantom program"
expect_ok "$tool" "$dev" smoke

section "3. one command at a time, checking the returned data"
out=$(root "$tool" "$dev" alloc 4096); echo "OUT AFDM id=$out"
in=$(root "$tool" "$dev" alloc 4096);  echo "IN  AFDM id=$in"
expect_ok "$tool" "$dev" write "$in" 0 hello-csd
expect_ok "$tool" "$ctrl" admin-load-phantom 2 1000
expect_ok "$tool" "$ctrl" admin-activate 2
expect_ok "$tool" "$dev" exec 2 "$in" "$out"
got=$(root "$tool" "$dev" read "$out" 0 16)
echo "$got"
if [[ $got == "68 65 6c 6c 6f 2d 63 73 64 00"* ]]; then
    echo "ok: OUT holds the bytes written to IN"
else
    echo "FAIL: OUT does not match IN"; fail=1
fi
expect_ok "$tool" "$ctrl" admin-deactivate 2
expect_ok "$tool" "$ctrl" admin-unload 2
root "$tool" "$dev" dealloc "$out" >/dev/null 2>&1
root "$tool" "$dev" dealloc "$in" >/dev/null 2>&1

section "4. a real program: vector add from a host shared library"
expect_ok "$tool" "$dev" smoke-so csd-vadd.so
expect_ok "$tool" "$dev" vadd-example csd-vadd.so

section "5. confinement: names outside csd_program_dir are refused"
expect_invalid_field() {
    local output status
    if output=$(root "$@" 2>&1); then
        echo 'FAIL: invalid request succeeded'; return 1
    else
        status=$?
    fi
    printf '%s\n' "$output"
    [[ $status == 1 && $output == *'status=0x4002'* ]] || {
        echo 'FAIL: unexpected rejection status'; return 1;
    }
}
expect_invalid_field "$tool" "$ctrl" admin-load-so 9 ../csd-vadd.so csd_vadd
expect_invalid_field "$tool" "$ctrl" admin-load-so 9 csd-vadd.so no_such_symbol

section "6. interpretation"
echo 'nr_cu controls host workers; different loaded programs can run concurrently.'
echo 'Repeated execution of one loaded program is serialized.'
echo 'csd_pause is off here; guest elapsed time includes host execution overhead.'

section "result"
if (( fail == 0 )); then echo "LAB-S4 PASS"; else echo "LAB-S4 FAIL"; fi
exit $fail
