# FEMU ATC26 learner pack

Edition: 2026-10-22. Public FEMU source:
`1918eb9795baa4483e7721429db5e58c54305878`.

Start with the website setup guide at
https://femu-ose.github.io/docs/tutorials/atc26/setup after this edition is
published. The local source includes the same setup instructions. This pack
is a candidate release; consult `lessons/errata.md` for actual execution
status. Videos, independent learner testing and classroom capacity testing
are not completed by building this pack.

## Contents

- `beamer/S0-*` through `S6-*`: presentation PDFs and flattened handouts.
- `labs/bin`: isolated launcher, guest runner and QMP helpers.
- `labs/guest`: destructive-device guard and executable lab checks.
- `labs/extension`: S6 teaching patch and guest regression.
- `lessons`: setup, exercises and current qualification status.
- `workbook.md`: predictions, interpretation questions and checklists.
- `manifest.json`: per-file hashes and the frozen source identity.

## Minimal host workflow

Prepare the Linux/KVM build and guest before class. `FEMU_BUILD` names the
directory containing `qemu-system-x86_64`; `BASE_IMAGE` is a prepared qcow2.
Run from this pack's root. Each experiment uses a fresh overlay and run directory.

```bash
export RUN_DIR=$(mktemp -d /tmp/atc26-run.XXXXXXXX)
qemu-img create -f qcow2 -F qcow2 -b "$BASE_IMAGE" "$RUN_DIR/guest.qcow2"
export OSIMGF="$RUN_DIR/guest.qcow2"
export SSH_PORT=18080
bash labs/bin/femu-lab.sh nossd
```

Second host terminal, with `RUN_DIR` set to the printed directory:

```bash
set -a
. "$RUN_DIR/connection.env"
set +a
bash labs/bin/preflight.sh -o "$RUN_DIR/results" labs/guest/lab-s0.sh /dev/nvme0n1
```

Substitute the actual guest namespace after inspecting its identity. The guard
requires matching serial and capacity and rejects mounted, partitioned, swap
or held devices. No lab should target a real SSD. Set `GUEST_USER`, `GUEST_PASS`
or `SSH_KEY` for the prepared image; do not put credentials in a shared receipt.

Stop only the current VM with
`python3 labs/bin/stop-vm.py "$RUN_DIR/qmp.sock"`. Preserve results before
starting another mode or comparison arm. Emulated media is volatile; a qcow2
snapshot of the OS disk does not snapshot the emulator's FTL or media.

S1 uses BBSSD and S2 uses FDP, both with 12 GiB exposed over 16 GiB raw NAND.
S0 uses the 4 GiB quickstart namespace. Never merge their results as if they
had identical capacity. The S1/S2 measured phase uses 16 GiB of verified writes.

## Source and licensing

The original tutorial materials are maintained with the FEMU ecosystem
project. FEMU itself and its implementation-derived extension follow
GPL-2.0-or-later. Third-party tutorial slides, videos, guest images and private
interview/research records are excluded from this pack. Cite the original FEMU
paper when using the emulator in research.
