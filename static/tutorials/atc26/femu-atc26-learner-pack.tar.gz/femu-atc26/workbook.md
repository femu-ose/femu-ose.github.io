# FEMU experiment workbook

Use one copy per experiment. This workbook supports the planned tutorial
release and the existing canonical walkthroughs. It is not a replacement for
the qualified launch/configuration files. Keep actual results, including
failures, in a separate attempt directory.

## Before running

**Research question:**

**Prediction and why:**

**Module and tutorial release:**

**Public FEMU commit and binary hash:**

**Host/guest kernel, tools and image:**

**Experimental namespace identity and size:**

**Why this is not the boot disk or an in-use device:**

**Configuration and workload hashes:**

**Initial state and reset procedure:**

## Record the controlled comparison

| Item | Baseline | Changed configuration |
| --- | --- | --- |
| Variable intentionally changed | | |
| Variables held fixed | | |
| Exposed namespace bytes | | |
| Raw NAND bytes | | |
| Mapping/GC/placement policy | | |
| Workload requests, byte count and seed | | |
| Conditioning procedure | | |
| Data-verification result | | |
| Exit status and result directory | | |

Explain any difference not intended by the experiment. If the runs process
different request counts or start from different states, decide whether the
comparison still answers the original question.

## Core checkpoints

### S0

Draw the path from the application to completion. Mark where payload data
moves and where modeled time is assigned. Identify the mode and source files.
Record the verified data size and readback result.

### S1

| Counter | Before | After | Delta | Unit |
| --- | --- | --- | --- | --- |
| Host writes | | | | |
| NAND writes | | | | |
| GC writes | | | | |
| Mapping writes, if applicable | | | | |
| Padding, if applicable | | | | |

State the exact WAF formula used and why its terms cover this configuration.
Explain whether GC occurred. A namespace fill is not proof of steady state.

### S2

Record the endurance group, placement identifiers, handles, and groups used.
Compute interval MBMW/HBMW from byte counters. Describe how you kept the
logical request sequence equivalent. Explain a neutral or negative placement
result as carefully as an improvement.

### S3

| Operation | Predicted state/write pointer | Observed state/write pointer | Status |
| --- | --- | --- | --- |
| Report initial zone | | | |
| Valid write/append | | | |
| Deliberate invalid operation | | | |
| Close/finish as assigned | | | |
| Reset | | | |

Explain what reset changes and why finish is different. Record data
verification before destructive reuse.

### S4

Record the input and program hashes, CPU reference output, CSD output, and
comparison result. Which bytes crossed the interface? Which clock did you
measure? Was `csd_pause` enabled? Does the result establish functional
correctness, modeled timing, or real-device performance?

### S5

Record the guest kernel configuration, region and access route, verified data,
and before/after cache/media counters. Explain why enumeration alone would not
prove the workload used the region.

### S6

Save the baseline, failing test, patch, and passing test. Explain why the test
fails before the fix and what incorrect implementation it would catch. Include
the command response schema and a checked invalid-input case.

## Interpret and hand over

**Observation:**

**Did it match the prediction? Explain through a state or code path:**

**Possible confounder and a follow-up experiment that distinguishes it:**

**What the current model does not represent for this question:**

**Steps another person needs to reproduce the result:**

**Independent rerun status and any intervention required:**

**Completion category:** independent / assisted / demonstrated / offline
analysis / blocked.

## Assessment rubric

Score each criterion 0, 1, or 2: absent/incorrect, partly supported, or complete
and supported by the receipt. This rubric evaluates an experiment, not the
student's speed.

| Criterion | What earns 2 |
| --- | --- |
| Question and prediction | Specific, testable, tied to the selected model |
| Control and state | Intended variable isolated; reset and conditioning explicit |
| Correctness | Device identity and data verification documented |
| Measurement | Raw evidence, units, interval, formula, and status agree |
| Interpretation | Explains the mechanism and a meaningful model limitation |
| Reproduction | Independent person can follow the bundle and obtain the checkpoint |

A result need not show a speedup or lower WAF to be a successful experiment.
An unexplained improvement is weaker evidence than a well-controlled neutral
result with a correct mechanism-level explanation.
