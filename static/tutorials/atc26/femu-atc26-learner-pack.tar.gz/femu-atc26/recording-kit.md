# FEMU video production kit

This is a recording script and shot list. No videos have been recorded for
this edition. Use the qualified experiment receipts and exported speaker
notes; do not turn an unexecuted command into staged successful output.

## Recording format

Begin with the research question and one observable outcome. Show the source
pin and environment briefly, then alternate the existing Beamer mechanism
figure with a legible terminal. Label every terminal Host, Guest or Monitor.
Use one experiment per chapter and pause before revealing the result.

Record narration from the session's `main-notes.pdf`. Replace references to
live pair work with a pause instruction. Keep the exact terminal command and
result in a text transcript alongside the video. Describe meaningful diagram
changes aloud. Captions must preserve units, property names and error codes.

Do not record account credentials, host access details or unrelated windows.
Use the disposable tutorial VM and its run directory.

## Chapter scripts and acceptance shots

| Chapter | Opening narration | Required shots and evidence | Closing question |
| --- | --- | --- | --- |
| Setup and first I/O, 8–12 min | "A benchmark can finish on the wrong device. We will first prove which device we are using and whether its bytes come back correctly." | Identity guard, explicit namespace, 1 MiB input/readback hashes, receipt directory | What did this prove about data, and what did it not prove about timing? |
| Follow one write, 8–12 min | "FEMU stores the payload and schedules the modeled operation along different paths." | S0 request-path reveal; pinned controller, poller and FTL source pointers | Which work remains in NoSSD? |
| GC and interval WAF, 10–15 min | "Overwriting logical data can require copying other live pages before space becomes reusable." | S1 geometry and victim diagram; before/after logs; verified fio jobs; complete WAF numerator | Did GC run, and which counter establishes that? |
| FDP placement, 10–15 min | "The host can describe data lifetimes while the device retains its FTL." | Mixed/separated-unit diagram; same workload configuration; handle status; 128-bit interval decoder | Would a neutral result still be informative? |
| ZNS lifecycle, 8–12 min | "A zone is an interface contract: the host must track valid writes and reuse." | Append, exact readback, expected invalid-write status, state walk and reset | Why is finish different from reset? |
| CSD round trip, 10–15 min | "Moving computation is useful only if we can verify its returned result and understand the timing boundary." | Phantom as preflight, real vector-add reference check, library/tool hashes, worker and clock explanation | Which bytes did the offload avoid moving? |
| CXL memory access, 10–15 min | "Device discovery is only the first checkpoint. We need a usable region and an actual verified memory access." | Qualified kernel config, region commit, devdax identity, readback and counter deltas | Which cache could hide an access from the device? |
| Extend one command, 12–18 min | "A small interface change should come with a test that fails for the right reason before the implementation exists." | qtest red result, four-field reply patch, green qtest including sentinel, guest regression | What incompatible response would your decoder reject? |
| Package an artifact, 6–10 min | "Another person should be able to test the claim using the files, not the author's memory." | Fresh attempt, hashes, reset description, raw logs, checker, manifest validation | Which missing file would block an independent rerun? |

## Edit and review

Cut waiting time, not error context. Show a short labelled excerpt of a long
workload and retain its full receipt in the download. Avoid generic speedup
claims based on an emulated timing result. If the environment fails, either
show the diagnosis accurately or postpone that chapter until qualification.

Before publishing a chapter, verify its commands against the downloadable
edition, captions against the spoken technical terms, diagram text on a small
screen, and links against the actual uploaded artifacts. Record upload URLs
and chapter timestamps only after the recordings exist.
