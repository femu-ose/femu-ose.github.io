# S2: source and qualification

Source pin: `1918eb9795baa4483e7721429db5e58c54305878`.

Mechanism and interface claims are traced in `../../ground-truth-2026-10-21.md`.
Runnable scripts live in `../../labs/`. Consult the release qualification
record for actual guest executions; a built slide is not a passed lab.

No historical performance values are used as expected results.
