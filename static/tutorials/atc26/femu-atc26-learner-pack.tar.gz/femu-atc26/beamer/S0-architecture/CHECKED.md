# Source and qualification

Current lab source pin: `1918eb9795baa4483e7721429db5e58c54305878`.
Architecture diagrams retain the established Beamer/TikZ style. October 1
measurements remain historical examples and do not establish current latency.
The revised lab contract uses explicit device guards and complete receipts.
See `../../labs/QUALIFICATION.md` for fresh execution results.
