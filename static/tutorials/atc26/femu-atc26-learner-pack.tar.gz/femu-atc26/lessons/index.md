---
title: "FEMU ATC26 tutorial"
description: "A frozen hands-on FEMU edition with seven sessions, verified lab contracts, slides and instructor guidance."
---

# FEMU ATC26 tutorial

**Edition:** public FEMU `1918eb9795baa4483e7721429db5e58c54305878`.
This is a candidate edition. Final Linux/KVM qualification was interrupted
by loss of host connectivity. Check the per-module status before assigning an
exercise. Session timing has not yet been independently rehearsed.

[Prepare your environment](setup.md) ·
[Get the learner pack](downloads.md) ·
[Read corrections and qualification](errata.md)

## What you will learn

Follow an I/O through the full system, verify returned data, measure media
work, explain host/device responsibilities, and package a reproducible change.

| Time | Session | Checkpoint |
| --- | --- | --- |
| 13:15–13:45 | [S0: Follow one I/O](s0.md) | Exact readback match |
| 13:45–14:15 | [S1: GC and WAF](s1.md) | Verified writes and interval accounting |
| 14:15–14:30 | Break | |
| 14:30–15:00 | [S2: FDP](s2.md) | Same workload, different placement |
| 15:00–15:30 | [S3: ZNS](s3.md) | State, write pointer and expected rejection |
| 15:30–16:00 | [S4: Computational storage](s4.md) | Real computation matches its reference |
| 16:00–16:30 | [S5: CXL](s5.md) | Usable region, readback and counters |
| 16:30–17:00 | [S6: Extend and reproduce](s6.md) | Red/green regression and artifact handoff |

Each exercise begins with a prediction and ends with evidence. Only the
paired placement experiments support a controlled performance comparison.
ZNS, CSD and CXL change the interface and answer different questions.

[Instructor guide](instructors.md) ·
[Community help](https://femu-ose.github.io/docs/community) · [How to cite FEMU](https://femu-ose.github.io/docs/research/cite)

Videos are not yet recorded. The learner pack includes speaking notes and
worksheets; no recording is implied by those materials.
