# Offline materials

- [Presentation](../release/femu-atc26-presentation.pdf)
- [Handout](../release/femu-atc26-handout.pdf)
- [Printable workbook](../release/femu-atc26-workbook.pdf)
- [Qualification](errata.md)
- [File hashes](../manifest.json)

Guest images and actual video recordings are not included.
