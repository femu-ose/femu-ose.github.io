# Offline materials

- [Presentation](../release/femu-atc26-presentation.pdf)
- [Handout](../release/femu-atc26-handout.pdf)
- [Speaking notes](../release/femu-atc26-notes.pdf)
- [Printable workbook](../release/femu-atc26-workbook.pdf)
- [Qualification](../labs/QUALIFICATION.md)
- [Recording script](../recording-kit.md)
- [File hashes](../manifest.json)

Guest images and actual video recordings are not included.
